﻿namespace AppLista03_GustavoAraujo
{
    partial class FrmExercicio01
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblExercicio1 = new System.Windows.Forms.Label();
            this.txtBox1 = new System.Windows.Forms.TextBox();
            this.txtBox2 = new System.Windows.Forms.TextBox();
            this.txtBox3 = new System.Windows.Forms.TextBox();
            this.lblN1 = new System.Windows.Forms.Label();
            this.lblN3 = new System.Windows.Forms.Label();
            this.lblN2 = new System.Windows.Forms.Label();
            this.btnMedia = new System.Windows.Forms.Button();
            this.btnPorcento = new System.Windows.Forms.Button();
            this.btnSomar = new System.Windows.Forms.Button();
            this.lblResultado = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblExercicio1
            // 
            this.lblExercicio1.AutoSize = true;
            this.lblExercicio1.Location = new System.Drawing.Point(98, 66);
            this.lblExercicio1.Name = "lblExercicio1";
            this.lblExercicio1.Size = new System.Drawing.Size(64, 13);
            this.lblExercicio1.TabIndex = 0;
            this.lblExercicio1.Text = "Exercício01";
            // 
            // txtBox1
            // 
            this.txtBox1.Location = new System.Drawing.Point(101, 147);
            this.txtBox1.Name = "txtBox1";
            this.txtBox1.Size = new System.Drawing.Size(100, 20);
            this.txtBox1.TabIndex = 1;
            // 
            // txtBox2
            // 
            this.txtBox2.Location = new System.Drawing.Point(249, 147);
            this.txtBox2.Name = "txtBox2";
            this.txtBox2.Size = new System.Drawing.Size(100, 20);
            this.txtBox2.TabIndex = 2;
            // 
            // txtBox3
            // 
            this.txtBox3.Location = new System.Drawing.Point(396, 147);
            this.txtBox3.Name = "txtBox3";
            this.txtBox3.Size = new System.Drawing.Size(100, 20);
            this.txtBox3.TabIndex = 3;
            this.txtBox3.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // lblN1
            // 
            this.lblN1.AutoSize = true;
            this.lblN1.Location = new System.Drawing.Point(98, 131);
            this.lblN1.Name = "lblN1";
            this.lblN1.Size = new System.Drawing.Size(53, 13);
            this.lblN1.TabIndex = 4;
            this.lblN1.Text = "Número 1";
            // 
            // lblN3
            // 
            this.lblN3.AutoSize = true;
            this.lblN3.Location = new System.Drawing.Point(393, 131);
            this.lblN3.Name = "lblN3";
            this.lblN3.Size = new System.Drawing.Size(53, 13);
            this.lblN3.TabIndex = 6;
            this.lblN3.Text = "Número 3";
            this.lblN3.Click += new System.EventHandler(this.lblN3_Click);
            // 
            // lblN2
            // 
            this.lblN2.AutoSize = true;
            this.lblN2.Location = new System.Drawing.Point(246, 131);
            this.lblN2.Name = "lblN2";
            this.lblN2.Size = new System.Drawing.Size(53, 13);
            this.lblN2.TabIndex = 7;
            this.lblN2.Text = "Número 2";
            // 
            // btnMedia
            // 
            this.btnMedia.Location = new System.Drawing.Point(249, 245);
            this.btnMedia.Name = "btnMedia";
            this.btnMedia.Size = new System.Drawing.Size(75, 23);
            this.btnMedia.TabIndex = 9;
            this.btnMedia.Text = "Média";
            this.btnMedia.UseVisualStyleBackColor = true;
            // 
            // btnPorcento
            // 
            this.btnPorcento.Location = new System.Drawing.Point(396, 245);
            this.btnPorcento.Name = "btnPorcento";
            this.btnPorcento.Size = new System.Drawing.Size(80, 23);
            this.btnPorcento.TabIndex = 10;
            this.btnPorcento.Text = "Porcentagem";
            this.btnPorcento.UseVisualStyleBackColor = true;
            // 
            // btnSomar
            // 
            this.btnSomar.Location = new System.Drawing.Point(101, 245);
            this.btnSomar.Name = "btnSomar";
            this.btnSomar.Size = new System.Drawing.Size(75, 23);
            this.btnSomar.TabIndex = 11;
            this.btnSomar.Text = "Somar";
            this.btnSomar.UseVisualStyleBackColor = true;
            this.btnSomar.Click += new System.EventHandler(this.btnSomar_Click);
            // 
            // lblResultado
            // 
            this.lblResultado.AutoSize = true;
            this.lblResultado.Location = new System.Drawing.Point(348, 338);
            this.lblResultado.Name = "lblResultado";
            this.lblResultado.Size = new System.Drawing.Size(184, 13);
            this.lblResultado.TabIndex = 12;
            this.lblResultado.Text = "O RESULTADO APARECERÁ AQUI!";
            // 
            // FrmExercicio01
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblResultado);
            this.Controls.Add(this.btnSomar);
            this.Controls.Add(this.btnPorcento);
            this.Controls.Add(this.btnMedia);
            this.Controls.Add(this.lblN2);
            this.Controls.Add(this.lblN3);
            this.Controls.Add(this.lblN1);
            this.Controls.Add(this.txtBox3);
            this.Controls.Add(this.txtBox2);
            this.Controls.Add(this.txtBox1);
            this.Controls.Add(this.lblExercicio1);
            this.Name = "FrmExercicio01";
            this.Text = "Exercício 1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblExercicio1;
        private System.Windows.Forms.TextBox txtBox1;
        private System.Windows.Forms.TextBox txtBox2;
        private System.Windows.Forms.TextBox txtBox3;
        private System.Windows.Forms.Label lblN1;
        private System.Windows.Forms.Label lblN3;
        private System.Windows.Forms.Label lblN2;
        private System.Windows.Forms.Button btnMedia;
        private System.Windows.Forms.Button btnPorcento;
        private System.Windows.Forms.Button btnSomar;
        private System.Windows.Forms.Label lblResultado;
    }
}

