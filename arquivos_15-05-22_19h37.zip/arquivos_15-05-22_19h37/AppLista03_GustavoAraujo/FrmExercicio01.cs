﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppLista03_GustavoAraujo
{
    public partial class FrmExercicio01 : Form
    {
        public FrmExercicio01()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void lblN3_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void btnSomar_Click(object sender, EventArgs e)
        {
            float numeroUm = float.Parse(txtBox1.Text);
            float numeroTres = float.Parse(txtBox3.Text);
            float somaUmTres;

            //Cálculos
            somaUmTres = numeroUm + numeroTres;


            //Mostrar resultados
            lblResultado.Text = somaUmTres.ToString("C");


        }
    }
}
