﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppLista03_GustavoAraujo
{
    public partial class FrmExercicio02 : Form
    {
        public FrmExercicio02()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            float valorPagar = float.Parse(txtPagar.Text);
            float valorGas = float.Parse(txtValorGas.Text);float qtdLitros;
            float qtdlitros;

            //Cálculo para se obter qtdLitros
            qtdLitros = valorGas / valorPagar;

            //Mostrar o resultado
            lblResultado.Text = qtdLitros.ToString();
        }
    }
}
