﻿namespace AppLista03_GustavoAraujo
{
    partial class FrmExercicio02
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblPagar = new System.Windows.Forms.Label();
            this.lblValorGas = new System.Windows.Forms.Label();
            this.txtPagar = new System.Windows.Forms.TextBox();
            this.txtValorGas = new System.Windows.Forms.TextBox();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.lblResultado = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblPagar
            // 
            this.lblPagar.AutoSize = true;
            this.lblPagar.BackColor = System.Drawing.Color.Transparent;
            this.lblPagar.ForeColor = System.Drawing.Color.White;
            this.lblPagar.Location = new System.Drawing.Point(248, 133);
            this.lblPagar.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPagar.Name = "lblPagar";
            this.lblPagar.Size = new System.Drawing.Size(114, 16);
            this.lblPagar.TabIndex = 0;
            this.lblPagar.Text = "VALOR A PAGAR";
            // 
            // lblValorGas
            // 
            this.lblValorGas.AutoSize = true;
            this.lblValorGas.BackColor = System.Drawing.Color.Transparent;
            this.lblValorGas.ForeColor = System.Drawing.Color.White;
            this.lblValorGas.Location = new System.Drawing.Point(248, 239);
            this.lblValorGas.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblValorGas.Name = "lblValorGas";
            this.lblValorGas.Size = new System.Drawing.Size(164, 16);
            this.lblValorGas.TabIndex = 1;
            this.lblValorGas.Text = "VALOR LITRO GASOLINA";
            // 
            // txtPagar
            // 
            this.txtPagar.Location = new System.Drawing.Point(471, 124);
            this.txtPagar.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtPagar.Name = "txtPagar";
            this.txtPagar.Size = new System.Drawing.Size(328, 22);
            this.txtPagar.TabIndex = 2;
            // 
            // txtValorGas
            // 
            this.txtValorGas.Location = new System.Drawing.Point(471, 230);
            this.txtValorGas.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtValorGas.Name = "txtValorGas";
            this.txtValorGas.Size = new System.Drawing.Size(328, 22);
            this.txtValorGas.TabIndex = 3;
            // 
            // btnCalcular
            // 
            this.btnCalcular.Font = new System.Drawing.Font("Impact", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalcular.Location = new System.Drawing.Point(385, 262);
            this.btnCalcular.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(284, 134);
            this.btnCalcular.TabIndex = 4;
            this.btnCalcular.Text = "CALCULAR";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // lblResultado
            // 
            this.lblResultado.AutoSize = true;
            this.lblResultado.BackColor = System.Drawing.Color.Transparent;
            this.lblResultado.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResultado.ForeColor = System.Drawing.Color.White;
            this.lblResultado.Location = new System.Drawing.Point(396, 430);
            this.lblResultado.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblResultado.Name = "lblResultado";
            this.lblResultado.Size = new System.Drawing.Size(254, 25);
            this.lblResultado.TabIndex = 5;
            this.lblResultado.Text = "O resultado aparecerá aqui!";
            // 
            // FrmExercicio02
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::AppLista03_GustavoAraujo.Properties.Resources.D_NQ_NP_876242_MLB27052112728_032018_O;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ClientSize = new System.Drawing.Size(955, 489);
            this.Controls.Add(this.lblResultado);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.txtValorGas);
            this.Controls.Add(this.txtPagar);
            this.Controls.Add(this.lblValorGas);
            this.Controls.Add(this.lblPagar);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "FrmExercicio02";
            this.Text = "FrmExercicio2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblPagar;
        private System.Windows.Forms.Label lblValorGas;
        private System.Windows.Forms.TextBox txtPagar;
        private System.Windows.Forms.TextBox txtValorGas;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.Label lblResultado;
    }
}